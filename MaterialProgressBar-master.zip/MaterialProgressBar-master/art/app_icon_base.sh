#!/bin/bash
inkscape --export-png="./app_icon.png" --export-width="512" --export-height="512" app_icon.svg
